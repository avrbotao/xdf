
/*
 *          |          _                     _______________________
 *          |\       _/ \_                  |                       |
 *          | \_    /_    \_                |    Alexandre Botao    |
 *          \   \__/  \__   \               |     www.botao.org     |
 *           \_    \__/  \_  \              |    55-11-8244-UNIX    |
 *             \_   _/     \ |              |  alexandre@botao.org  |
 *               \_/        \|              |_______________________|
 *                           |
 */

/*	 _______________________________________________________________
 *	|																|
 *	|	xdf										Exquisite `df'(1)	|
 *	|_______________________________________________________________|
 */

/*  ____________________________________________________________________
 * |                                                                    |
 * | Copyright [2010-2021] [alexandre botao]                            |
 * |                                                                    |
 * | Licensed under the Apache License, Version 2.0 (the "License");    |
 * | you may not use this file except in compliance with the License.   |
 * | You may obtain a copy of the License at                            |
 * |                                                                    |
 * |     https://www.apache.org/licenses/LICENSE-2.0                    |
 * |                                                                    |
 * | Unless required by applicable law or agreed to in writing, file or |
 * | software distributed under the terms of the License is distributed |
 * | on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, |
 * | either express or implied. See the License for the specific        |
 * | language governing permissions and limitations under the License.  |
 * |____________________________________________________________________|
 */

# if 0						/*	version.[ch]	*/
# define SWNAME	"xdf"
# define SWVERS	"1.5.83"
# define SWFORG	"$"				/*	"$" = stable	*/
# define SWDATE	"2021-11-27"
# define SWCOPY	"(apache)"
# define SWAUTH	"alexandre@botao.org"
# endif

/*____________________________________________________________________________
*/

# include <time.h>
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <signal.h>
# include <unistd.h>
# include <sys/utsname.h>

# include "abcs.h"

# include "version.h"

/*	__	__	__	__	__	__	__	__	__
*/

# ifdef CYGWIN
# define	ulong_t		unsigned long
# endif /* CYGWIN */

# ifdef LINUX
# include <stdint.h>
# define ulong_t	ulong
# endif /* LINUX */

# ifdef USE_STATFS
# ifndef ANYBSD
# include <sys/vfs.h>
# endif
struct statfs	sfsbuf ;
int32_t	x_bavail;  /* free blocks available to non-superuser */
int32_t	x_bfree;   /* free blocks */
int32_t	x_blocks;  /* total blocks in file system */
int32_t	x_bsize;   /* fundamental file system block size in bytes */
int32_t x_bused;
# endif /* USE_STATFS */

# ifdef USE_STATVFS
# include <sys/types.h>
# include <sys/statvfs.h>
struct statvfs	svfsbuf ;
# ifdef NETBSD
typedef unsigned long ulong_t ;
# endif
ulong_t x_bsize;              /* preferred file system block size */
ulong_t x_frsize;             /* fundamental file system block size */
ulong_t x_blocks;             /* total blocks of f_frsize on file system */
ulong_t x_size;               /* size of file system in f_frsize unit */
ulong_t x_bfree;              /* free blocks */
ulong_t x_bavail;             /* blocks available to non-superuser */
ulong_t x_bused;
# endif /* USE_STATVFS */

# ifdef AIX
# include <mntent.h>
# define X_FILESYSLIST	MNTTAB		/* "/etc/filesystems"	*/
# define X_MOUNTEDLIST	MOUNTED		/* "/etc/mtab"		*/
# define XDF_IGNLST "procfs"
# define XDF_SYSLST "/","/home","/opt","/proc","/usr","/var","/tmp","/var/adm/ras/livedump"
# endif /* AIX */

# ifdef HPUX
# include <mntent.h>
# define X_FILESYSLIST	MNT_CHECKLIST	/* "/etc/fstab"		*/
#   ifdef HPUX1111
#	define X_MOUNTEDLIST	"/etc/fstab"	/* avoid hangs */
#   else
#	define X_MOUNTEDLIST	MNT_MNTTAB	/* "/etc/mnttab"	*/
#   endif
# define XDF_IGNLST "swap"
# define XDF_SYSLST "/","/home","/opt","/stand","/usr","/var","/tmp"
# endif /* HPUX */

# ifdef LINUX
# include <mntent.h>
# define X_FILESYSLIST	MNTTAB		/* "/etc/fstab"		*/
# define X_MOUNTEDLIST	MOUNTED		/* "/etc/mtab"		*/
# define XDF_IGNLST "proc","tmpfs","sysfs","devpts","fusectl","nfsd","securityfs","binfmt_misc","fuse.gvfs-fuse-daemon","squashfs","devtmpfs"
# define XDF_SYSLST "/","/boot","/dev","/home","/opt","/usr","/var","/tmp"
# endif /* LINUX */

# ifdef CYGWIN
# include <mntent.h>
# define X_FILESYSLIST	MNTTAB		/* "/etc/fstab"		*/
# define X_MOUNTEDLIST	MOUNTED		/* "/etc/mtab"		*/
# define XDF_IGNLST "proc","C:/cygwin","C:/cygwin/bin","C:/cygwin/lib"
# define XDF_SYSLST "/","/usr/bin","/usr/lib"
# endif /* CYGWIN */

# ifdef SUNX
# include <sys/mnttab.h>
# define X_FILESYSLIST	"/etc/vfstab"
# define X_MOUNTEDLIST	MNTTAB		/* "/etc/mnttab"	*/
# define setmntent(N,M)	fopen(N,M)
# define endmntent(P)	fclose(P)
# define XDF_IGNLST "ctfs","proc","mnttab","tmpfs","objfs","sharefs","fd"
# define XDF_SYSLST "/","/devices","/opt","/usr","/var","/tmp","/etc/svc/volatile","/var/run"
# endif /* SUNX */

#ifdef FREEBSD
# include <sys/param.h>
# include <sys/ucred.h>
# include <sys/mount.h>
typedef		struct statfs		FSSBUF ;
typedef		long			fsstabsiz_t ;
# define	F_BLOCKSIZE		f_bsize
# define	FSSFILL			getfsstat
# define XDF_IGNLST "devfs","procfs","linprocfs"
# define XDF_SYSLST "/","/var","/usr","/tmp"
#endif

#ifdef OPENBSD
# include <sys/param.h>
# include <sys/mount.h>
typedef		struct statfs		FSSBUF ;
typedef		long			fsstabsiz_t ;
# define	F_BLOCKSIZE		f_bsize
# define	FSSFILL			getfsstat
# define XDF_IGNLST "swap"
# define XDF_SYSLST "/","/home","/usr"
#endif

#ifdef NETBSD
# include <sys/types.h>
# include <sys/statvfs.h>
typedef		struct statvfs		FSSBUF ;
typedef		size_t			fsstabsiz_t ;
# define	F_BLOCKSIZE		f_frsize
# define	FSSFILL			getvfsstat
# define XDF_IGNLST "kernfs","ptyfs","procfs"
# define XDF_SYSLST "/"
#endif

/*	__	__	__	__	__	__	__	__	__
*/

# define	XDF_STR		0x0001
# define	XDF_INT		0x0002
# define	XDF_BIG		0x0004
# define	XDF_PCT		0x0008
# define	XDF_UNT		0x0020
# define	XDF_SOL		0x0040
# define	XDF_EOL		0x0080
# define	XDF_HEAD	0x0100
# define	XDF_PLUS	0x0200
# define	XDF_TAIL	0x0400
# define	XDF_FOOT	XDF_TAIL
# define	XDF_ITEM	0x0800
# define	XDF_BODY	XDF_ITEM
# define	XDF_DOT		0x1000
# define	XDF_HUMAN	0x2000

# define	MAXDIRLST	8192
# define	DFLTIMOUT	2

# ifdef		ANYBSD
# define	MAXFSS		1024
# endif		/* ANYBSD */

/*	__	__	__	__	__	__	__	__	__
*/

/* FIXME: opt int64_t , intmax_t */

long long	xfs_blksiz ;
long long	xfs_totbyt ;
long long	xfs_usebyt ;
long long	xfs_avabyt ;

int		xfs_caperc ;
int		xfs_tmperc ;	/* temporary '%free' ( 100 - caperc ) */

int		sumcaperc = 0LL ;
int		sumtmperc = 0LL ;

long long	sumtotbyt = 0LL ;
long long	sumusebyt = 0LL ;
long long	sumavabyt = 0LL ;

long long	unit = 1 ;

int	borderflag = 0 ;
int	sectorflag = 0 ;
int	frameflag = 0 ;
int	identflag = 0 ;
int	fstabflag = 0 ;
int	verbflag = 0 ;
int	versflag = 0 ;
int	echoflag = 0 ;
int	hostflag = 0 ;
int	ansiflag = 0 ;
int	kiloflag = 0 ;
int	megaflag = 0 ;
int	gigaflag = 0 ;
int	teraflag = 0 ;
int	intlflag = 0 ;
int	humanflag = 0 ;
int	bytesflag = 0 ;
int	siflag = 0 ;
int	htmlflag = 0 ;
int	helpflag = 0 ;
int	listflag = 0 ;
int	freeflag = 0 ;
int	sumflag = 0 ;
int	volflag = 0 ;
int	sizflag = 0 ;
int	useflag = 0 ;
int	avaflag = 0 ;
int	capflag = 0 ;
int	legflag = 0 ;
int	csvflag = 0 ;
int	hdrflag = 0 ;
int	sysflag = 0 ;
int	regflag = 0 ;
int	nfsflag = 0 ;
int	dotsflag = 0 ;
int	mountflag = 0 ;
int	sorthelp = 0 ;

int	volcount = 0 ;
int	timedout = 0 ;
int	xtimeout = DFLTIMOUT ;

int	hostwid = 12 ;
int	volwid = 24 ;
int	dirwid = 24 ;
int	bigwid = 15 ;

char	csvsep = ';' ;

char	xdf_vertbar = '|' ;
char	xdf_horzbar = '-' ;
char	xdf_plusign = '+' ;
char	xdf_upprtee = 'v' ;
char	xdf_lowrtee = '^' ;
char	xdf_lefttee = '>' ;
char	xdf_rightee = '<' ;
char	xdf_upprleft = '/' ;
char	xdf_uppright = '\\' ;
char	xdf_lowrleft = '\\' ;
char	xdf_lowright = '/' ;

char *	xdf_smacs = "\033(0" ;
char *	xdf_rmacs = "\033(B" ;
char *	lotime = "localtime" ;
char *	osname = "Unix" ;
char *	osvers = "5" ;
char *	osrels = "4" ;
char *	forgid = SWFORG ;
char *	noname = "NodeName" ;
char *	hostname = "hostname" ;
char *	unitname = "bytes" ;

char	versno [16] ;
char	banner [80] ;
char	hident [128] ;

char * ignlst [] = { XDF_IGNLST , NULL } ;
char * syslst [] = { XDF_SYSLST , NULL } ;

char * dirlst [MAXDIRLST] ;

struct utsname	utsbuf ;

# ifdef		ANYBSD

int fsscount ;
int fsno ;
int fssflags = 0 ;

fsstabsiz_t fsstabsiz ;

FSSBUF fsstab [ MAXFSS ] ;

FSSBUF * fssp ;

# endif		/* ANYBSD */

/*	__	__	__	__	__	__	__	__	__
*/

void wakeup (signo) int signo ; {
	alarm (0) ;
	signal (SIGALRM, wakeup) ;
	alarm (0) ;
	++timedout ;
}

/*				 _______________________________________________________
 *				|														|
 *				|	lltoa + long long to ascii conversion ...			|
 *				|_______________________________________________________|
 */

# define	MAXWID		128
# define	DOT			'.'
# define	NUL			'\0'

char * lltoa (val, wid, flg) long long val ; int wid, flg ; {

	static char buf [MAXWID] = { '+' } ;
	register char * bp = buf + ( MAXWID - 1 ) ;
	int neg = 0 ;
	int tk = 1 ;						/* thousands' counter			*/

	if (val < 0) {
		val = -val ;
		neg = 1 ;
	}

	memset ( buf , NUL , MAXWID ) ; /* FIXME: why ? */

	do {
		if (flg & XDF_DOT) {
			if ( (tk % 4) == 0 ) {
				*--bp = DOT ;
				++tk ;
			}
		}
		*--bp = '0' + (char) (val % 10) ;
		++tk ;
		if (tk >= wid)
			break ;
	} while ((val /= 10) > 0) ;

	if (neg == 1) {
		*--bp = '-' ;
		++tk ;
	}

	while (tk <= wid) {
		*--bp = ' ' ;
		++tk ;
	}
	return bp ;
}

/*	__	__	__	__	__	__	__	__	__
*/

int spoff (char *buf, off_t size) {
	static char * unab = "BKMGTPEZY" ;
	int idx, usize = siflag ? 1000 : 1024 ;

	if (humanflag || siflag) {
		for (idx = size < usize ? 0 : 1 ; size >= (usize * usize) ; idx++, size /= usize) ;
		if (!idx) {
			return sprintf(buf, "%4d", (int) size) ;
		} else {
			return sprintf(buf, ((size / usize) >= 10) ? "%3.0f%c" : "%3.1f%c", (float) size / (float) usize, unab[idx]) ;
		}
	} else {
		return sprintf(buf, "%18lld", (long long)size) ;
	}
}

/*	__	__	__	__	__	__	__	__	__
*/

void dodraw (chr) int chr ; {
	if (ansiflag)
		printf ("%s%c%s", xdf_smacs, chr, xdf_rmacs) ;
	else
		printf ("%c", chr) ;
}

/*	__	__	__	__	__	__	__	__	__
*/

void showinfo (ptr, wid, flg) char * ptr ; int wid , flg ; {

	int		tmpint ;
	long long	tmpbig ;
	static	char	tmptxt [32] ;
	static	char	fmt [16] ;
		char *	tdalig = "right" ;

	if ( csvflag )
		wid = 0 ;

	if ( wid ) {
		if ( flg & XDF_STR ) {
			sprintf (fmt, "%%%d.%d", wid, wid < 0 ? -wid : wid) ;
		} else {
			sprintf (fmt, "%%%d", wid) ;
		}
	} else {
		sprintf (fmt, "%c", '%') ;
	}

	if ( wid < 0 )
		tdalig = "left" ;

	if ( flg & XDF_SOL ) {
		if ( htmlflag ) {
			if ( flg & XDF_HEAD ) {
				printf ("    <thead>\n") ;
				printf ("     <tr align=center>\n") ;
			}
			if ( flg & XDF_BODY ) {
				printf ("    <tbody>\n") ;
				printf ("     <tr align=left>\n") ;
			}
			if ( flg & XDF_FOOT ) {
				printf ("    <tfoot>\n") ;
				printf ("     <tr align=center>\n") ;
			}
		}
		if ( frameflag ) {
			dodraw (xdf_vertbar) ;
			printf ("%c", ' ') ;
		}
		return ;
	}

	if ( flg & XDF_UNT ) {
#if 0
		if ( gigaflag && bigwid < 9 ) /* FIXME: why ? */
			unitname = "G" ;
#endif
		sprintf (tmptxt, "%s %s", ptr, unitname) ;
		ptr = tmptxt ;
	}

	if ( htmlflag ) {
		printf ("      <td align=%s>\t", tdalig) ;
	}

	if ( flg & XDF_STR ) {
		strcat (fmt, "s") ;
		printf (fmt, ptr) ;
	}

	if ( flg & XDF_INT ) {
		tmpint = *(int*)ptr ;
		strcat (fmt, "d") ;
		printf (fmt, tmpint) ;
	}

	if ( flg & XDF_BIG ) {
		tmpbig = *(long long *)ptr ;
		if ( flg & XDF_HUMAN ) {
			spoff (tmptxt, (off_t) tmpbig) ;
			strcat (fmt, "s") ;
			printf (fmt, tmptxt) ;
		} else {
			if ( flg & XDF_DOT ) {
				strcat (fmt, "s") ;
				printf (fmt, lltoa (tmpbig, wid, XDF_DOT)) ;
			} else {
				strcat (fmt, "lld") ;
				printf (fmt, tmpbig) ;
			}
		}
	}

	if ( flg & XDF_PCT ) {
		printf ("%c", '%') ;
	}

	if ( htmlflag ) {
		printf ("\t</td>\n") ;
	}

	if ( flg & XDF_EOL ) {
		if ( htmlflag ) {
			if ( flg & XDF_HEAD ) {
				printf ("     </tr>\n") ;
				printf ("    </thead>\n") ;
			}
			if ( flg & XDF_BODY ) {
				printf ("     </tr>\n") ;
				printf ("    </tbody>\n") ;
			}
			if ( flg & XDF_FOOT ) {
				printf ("     </tr>\n") ;
				printf ("    </tfoot>\n") ;
			}
		}
		if ( frameflag ) {
			printf ("%c", ' ') ;
			dodraw (xdf_vertbar) ;
		}
		if ( ! htmlflag )
			printf ("\n") ;
	} else {
		if ( csvflag ) {
			printf ("%c", csvsep) ;
		} else {
			if ( frameflag ) {
				printf ("%c", ' ') ;
				dodraw (xdf_vertbar) ;
				printf ("%c", ' ') ;
			} else {
				if ( ! htmlflag )
					printf (" ") ;
			}
		}
	}
}

/*	__	__	__	__	__	__	__	__	__
*/

void ydf (vol, name) char * vol , * name ; { /* o.s.-independent stuff */

	if ( vol == NULL )
		vol = "unknown" ;

	x_bused  = x_blocks - x_bfree ;

	xfs_totbyt = ( xfs_blksiz * x_blocks ) / unit ;
	xfs_usebyt = ( xfs_blksiz * x_bused ) / unit ;
	xfs_avabyt = ( xfs_blksiz * x_bavail ) / unit ;

	xfs_caperc = xfs_totbyt ? ( xfs_usebyt * 100 ) / xfs_totbyt : 0 ;
	xfs_tmperc = 100 - xfs_caperc ;

	showinfo (NULL, 0, XDF_SOL | XDF_ITEM) ;

	if ( hostflag ) {
		showinfo (hostname, -hostwid, XDF_STR) ;
	}

	if ( volflag ) {
		showinfo (vol, -volwid, XDF_STR) ;
	}

	if ( sizflag ) {
		if ( humanflag ) {
			showinfo ( (char *) &xfs_totbyt, bigwid, XDF_BIG | XDF_HUMAN ) ;
		} else {
			showinfo ( (char *) &xfs_totbyt, bigwid, XDF_BIG | ( dotsflag ? XDF_DOT : 0x0000 ) ) ;
		}
	}

	if ( useflag ) {
		if ( humanflag ) {
			showinfo ( (char *) &xfs_usebyt, bigwid, XDF_BIG | XDF_HUMAN ) ;
		} else {
			showinfo ( (char *) &xfs_usebyt, bigwid, XDF_BIG | ( dotsflag ? XDF_DOT : 0x0000 ) ) ;
		}
	}

	if ( avaflag ) {
		if ( humanflag ) {
			showinfo ( (char *) &xfs_avabyt, bigwid, XDF_BIG | XDF_HUMAN ) ;
		} else {
			showinfo ( (char *) &xfs_avabyt, bigwid, XDF_BIG | ( dotsflag ? XDF_DOT : 0x0000 ) ) ;
		}
	}

	if ( capflag ) {
		showinfo ( (char *) &xfs_caperc, 4, XDF_INT|XDF_PCT) ;
	}

	if ( freeflag ) {
		showinfo ( (char *) &xfs_tmperc, 4, XDF_INT|XDF_PCT) ;
	}

	if ( mountflag ) {
		showinfo (name, -dirwid, XDF_STR|XDF_EOL|XDF_ITEM) ;
	}

	++volcount ;

	if ( sumflag ) {
		sumtotbyt += xfs_totbyt ;
		sumusebyt += xfs_usebyt ;
		sumavabyt += xfs_avabyt ;
		sumcaperc += xfs_caperc ;
		sumtmperc += xfs_tmperc ;
	}
}

/*	__	__	__	__	__	__	__	__	__
*/

void xdf (vol, name) char * vol , * name ; {

	int	rd = -1 ;

# ifdef	ANYBSD
	if ( vol == NULL /* || listflag */ ) {
# endif	/* ANYBSD */

		signal (SIGALRM, wakeup) ; timedout = 0 ; alarm (xtimeout) ;

# ifdef USE_STATFS
		rd = statfs (name, &sfsbuf) ;
# endif /* USE_STATFS */

# ifdef USE_STATVFS
		rd = statvfs (name, &svfsbuf) ;
# endif /* USE_STATVFS */

		alarm (0) ;

		if ( timedout ) {
			fprintf (stderr, "** timeout on %s\n", name != NULL ? name : vol != NULL ? vol : "unknown") ;
			return ;
		}

		if ( rd != 0 ) {
			perror (name) ;
			return ;
		}

# ifdef	ANYBSD
	} else {
		x_bavail = fssp->f_bavail ;
		x_bfree  = fssp->f_bfree ;
		x_blocks = fssp->f_blocks ;
		x_bsize  = fssp->F_BLOCKSIZE ;
		xfs_blksiz = x_bsize ;
		goto osis ;
	}
# endif	/* ANYBSD */

# ifdef USE_STATFS
	x_bavail = sfsbuf.f_bavail ;
	x_bfree  = sfsbuf.f_bfree ;
	x_blocks = sfsbuf.f_blocks ;
	x_bsize  = sfsbuf.f_bsize ;
	xfs_blksiz = x_bsize ;
# endif /* USE_STATFS */

# ifdef USE_STATVFS
	x_bavail = svfsbuf.f_bavail ;
	x_bfree  = svfsbuf.f_bfree ;
	x_blocks = svfsbuf.f_blocks ;
	x_bsize  = svfsbuf.f_bsize ;
# ifdef HAS_VFS_F_SIZE
	x_size   = svfsbuf.f_size ;
# endif /* HAS_VFS_F_SIZE */
	x_frsize = svfsbuf.f_frsize ;
	xfs_blksiz = x_frsize ;
# endif /* USE_STATVFS */

# ifdef	ANYBSD
osis:
# endif	/* ANYBSD */
	if ( x_blocks == 0 )
		return ;

	ydf ( vol , name ) ; /* o.s.-independent stuff */
}

/*	__	__	__	__	__	__	__	__	__
*/

void dodash (dash, plus, wid, flg) int dash, plus, wid, flg ; {
	int i ;

	for ( i = 2+wid ; i ; --i )
		dodraw (dash) ;
	if ( ! ( flg & XDF_EOL ) )
		dodraw (plus) ;
}

/*	__	__	__	__	__	__	__	__	__
*/

void dashes (flg) int flg ; {
	static	char	west, plus, east ;

	if ( ! frameflag )
		return ;

	if ( flg & XDF_HEAD ) {
		west = xdf_upprleft ;
		plus = xdf_upprtee ;
		east = xdf_uppright ;
	}

	if ( flg & XDF_PLUS ) {
		west = xdf_lefttee ;
		plus = xdf_plusign ;
		east = xdf_rightee ;
	}

	if ( flg & XDF_TAIL ) {
		west = xdf_lowrleft ;
		plus = xdf_lowrtee ;
		east = xdf_lowright ;
	}

	dodraw (west) ;

	if ( hostflag ) {
		dodash (xdf_horzbar, plus, hostwid, 0) ;
	}

	if ( volflag ) {
		dodash (xdf_horzbar, plus, volwid, 0) ;
	}

	if ( sizflag ) {
		dodash (xdf_horzbar, plus, bigwid, 0) ;
	}

	if ( useflag ) {
		dodash (xdf_horzbar, plus, bigwid, 0) ;
	}

	if ( avaflag ) {
		dodash (xdf_horzbar, plus, bigwid, 0) ;
	}

	if ( capflag || freeflag ) {
		dodash (xdf_horzbar, plus, 5, 0) ;
	}

	if ( mountflag ) {
		dodash (xdf_horzbar, plus, dirwid, XDF_EOL) ;
	}

	dodraw (east) ;
	printf ("%c", '\n') ;
}

/*	__	__	__	__	__	__	__	__	__
*/

int chkign (name) char * name ; {

	char * * pp ;

	if ( name == NULL )
		return 1 ;

	for ( pp = ignlst ; *pp != NULL ; ++pp )
		if ( strcmp ( name , *pp ) == 0 )
			return 3 ;

	return 0 ;
}

/*	__	__	__	__	__	__	__	__	__
*/

int chksys (name) char * name ; {

	char * * pp ;

	if ( name == NULL )
		return 1 ;

	for ( pp = syslst ; *pp != NULL ; ++pp )
		if ( strcmp ( name , *pp ) == 0 )
			return 3 ;

	return 0 ;
}

/*	__	__	__	__	__	__	__	__	__
*/

void getuname () {
	int rd ;

	rd = uname (&utsbuf) ;

	if ( rd == -1 )
		perror ("uname") ;

	osname = utsbuf.sysname ;
	noname = utsbuf.nodename ;
	osvers = utsbuf.version ;
	osrels = utsbuf.release ;
}

/*	__	__	__	__	__	__	__	__	__
*/

void showhdr () {

	showinfo (NULL, 0, XDF_SOL | XDF_HEAD) ;
	if ( hostflag ) {
		showinfo ("host", -hostwid, XDF_STR /* | XDF_HEAD */) ;
	}
	if ( volflag ) {
		showinfo ("volume", -volwid, XDF_STR /* | XDF_HEAD */) ;
	}
	if ( sizflag ) {
		showinfo ("size", bigwid, XDF_STR | XDF_UNT /* | XDF_HEAD */) ;
	}
	if ( useflag ) {
		showinfo ("used", bigwid, XDF_STR | XDF_UNT /* | XDF_HEAD */) ;
	}
	if ( avaflag ) {
		showinfo ("free", bigwid, XDF_STR | XDF_UNT /* | XDF_HEAD */) ;
	}
	if ( capflag ) {
		showinfo ("%used", 5, XDF_STR /* | XDF_HEAD */) ;
	}
	if ( freeflag ) {
		showinfo ("%free", 5, XDF_STR /* | XDF_HEAD */) ;
	}
	if ( mountflag ) {
		showinfo ("mounted", -dirwid, XDF_STR | XDF_EOL | XDF_HEAD) ;
	}
	dashes (XDF_PLUS) ;
}

/*	__	__	__	__	__	__	__	__	__
*/

void showsums () {
	sumcaperc /= volcount ;
	sumtmperc /= volcount ;
	dashes (XDF_PLUS) ;
	showinfo (NULL, 0, XDF_SOL | XDF_FOOT) ;
	if ( hostflag ) {
		showinfo (hostname, -hostwid, XDF_STR) ;
	}
	if ( volflag ) {
		showinfo ("total", -volwid, XDF_STR) ;
	}
	if ( sizflag ) {
		if ( humanflag ) {
			showinfo ( (char *) &sumtotbyt, bigwid, XDF_BIG | XDF_HUMAN ) ;
		} else {
			showinfo ( (char *) &sumtotbyt, bigwid, XDF_BIG | ( dotsflag ? XDF_DOT : 0x0000 ) ) ;
		}
	}
	if ( useflag ) {
		if ( humanflag ) {
			showinfo ( (char *) &sumusebyt, bigwid, XDF_BIG | XDF_HUMAN ) ;
		} else {
			showinfo ( (char *) &sumusebyt, bigwid, XDF_BIG | ( dotsflag ? XDF_DOT : 0x0000 ) ) ;
		}
	}
	if ( avaflag ) {
		if ( humanflag ) {
			showinfo ( (char *) &sumavabyt, bigwid, XDF_BIG | XDF_HUMAN ) ;
		} else {
			showinfo ( (char *) &sumavabyt, bigwid, XDF_BIG | ( dotsflag ? XDF_DOT : 0x0000 ) ) ;
		}
	}
	if ( capflag ) {
		showinfo ( (char *) &sumcaperc, 4, XDF_INT|XDF_PCT) ;
	}
	if ( freeflag ) {
		showinfo ( (char *) &sumtmperc, 4, XDF_INT|XDF_PCT) ;
	}
	if ( mountflag ) {
# ifdef ORIG
		showinfo ( capflag ? "average" : "total" , -dirwid, XDF_STR|XDF_EOL|XDF_FOOT ) ;
# else
		showinfo ( (char *) &volcount , -dirwid, XDF_INT|XDF_EOL|XDF_FOOT ) ;
# endif
	}
}

/*	__	__	__	__	__	__	__	__	__
*/

int usage () {
	fprintf (stderr, " use: %s [-options]\n\n", SWNAME) ;
	fprintf (stderr, " -? : show usage help\n\n" ) ;
	if ( sorthelp ) {
		fprintf (stderr, " -5 : show sizes in 512-byte-sector units\n" ) ;
		fprintf (stderr, " -A : frame output in ANSI line chars (*1)\n" ) ;
		fprintf (stderr, " -a : show available space\n" ) ;
		fprintf (stderr, " -B : output informations in HTML format (*2)\n" ) ;
		fprintf (stderr, " -b : show sizes in bytes (default except '-L')\n" ) ;
		fprintf (stderr, " -C : output informations in CSV format (*2)\n" ) ;
		fprintf (stderr, " -c : show capacity ('%% full', or '%% used')\n" ) ;
		fprintf (stderr, " -d 'delimiter' : CSV 'alternate field separator'\n" ) ;
		fprintf (stderr, " -E : ignore 'echo' volumes (eg. cygwin)\n" ) ;
		fprintf (stderr, " -F : frame output in ASCII chars (*2)\n" ) ;
		fprintf (stderr, " -f : show '%% free' instead (opposite of -c)\n" ) ;
		fprintf (stderr, " -G : show sizes in GiB\n" ) ;
		fprintf (stderr, " -h : prepend host name\n" ) ;
		fprintf (stderr, " -H : show header\n" ) ;
		fprintf (stderr, " -i : international units (eg. KB MB GB)\n" ) ;
		fprintf (stderr, " -h : show sizes in human readable format (e.g., 123K 2,5M 3G)\n" ) ;
		fprintf (stderr, " -K : show sizes in KiB\n" ) ;
		fprintf (stderr, " -L : legacy df layout\n" ) ;
		fprintf (stderr, " -l : show volume device\n" ) ;
		fprintf (stderr, " -m : frame output in HTML format (*1)\n" ) ;
		fprintf (stderr, " -M : show sizes in MiB\n" ) ;
		fprintf (stderr, " -n <pathname> [ -n ... ] : process just these\n" ) ;
		fprintf (stderr, " -N : show nfs filesystems\n" ) ;
		fprintf (stderr, " -o : sort usage help\n" ) ;
		fprintf (stderr, " -O : show only 'operating system' (eg. /usr) filesystems\n" ) ;
		fprintf (stderr, " -p : show mount point\n" ) ;
		fprintf (stderr, " -R : show only 'regular' ('non-O.S.') filesystems\n" ) ;
		fprintf (stderr, " -S : show total sizes and capacity average\n" ) ;
		fprintf (stderr, " -s : show volume size\n" ) ;
		fprintf (stderr, " -T : show sizes in TiB\n" ) ;
		fprintf (stderr, " -t : use 'static' (eg. fstab) filesystems list\n" ) ;
		fprintf (stderr, " -u : show used space\n" ) ;
		fprintf (stderr, " -V : show version\n" ) ;
		fprintf (stderr, " -v : verbose mode\n" ) ;
		fprintf (stderr, " -X : extra host informations\n" ) ;
		fprintf (stderr, " -z : thousand separator\n" ) ;
	} else {
		fprintf (stderr, " -h : prepend host name\n" ) ;
		fprintf (stderr, " -l : show volume device\n" ) ;
		fprintf (stderr, " -s : show volume size\n" ) ;
		fprintf (stderr, " -u : show used space\n" ) ;
		fprintf (stderr, " -a : show available space\n" ) ;
		fprintf (stderr, " -c : show capacity ('%% full', or '%% used')\n" ) ;
		fprintf (stderr, " -f : show '%% free' instead (opposite of -c)\n" ) ;
		fprintf (stderr, " -p : show mount point\n" ) ;
		fprintf (stderr, " -5 : show sizes in 512-byte-sector units\n" ) ;
		fprintf (stderr, " -K : show sizes in KiB\n" ) ;
		fprintf (stderr, " -M : show sizes in MiB\n" ) ;
		fprintf (stderr, " -G : show sizes in GiB\n" ) ;
		fprintf (stderr, " -T : show sizes in TiB\n" ) ;
		fprintf (stderr, " -b : show sizes in bytes (default except '-L')\n" ) ;
		fprintf (stderr, " -z : thousand separator\n" ) ;
		fprintf (stderr, " -h : show sizes in human readable format (e.g., 123K 2,5M 3G)\n" ) ;
		fprintf (stderr, " -i : international units (eg. KB MB GB)\n" ) ;
		fprintf (stderr, " -O : show only 'operating system' (eg. /usr) filesystems\n" ) ;
		fprintf (stderr, " -R : show only 'regular' ('non-O.S.') filesystems\n" ) ;
		fprintf (stderr, " -N : show nfs filesystems\n" ) ;
		fprintf (stderr, " -A : frame output in ANSI line chars (*1)\n" ) ;
		fprintf (stderr, " -m : frame output in HTML format (*1)\n" ) ;
		fprintf (stderr, " -F : frame output in ASCII chars (*2)\n" ) ;
		fprintf (stderr, " -E : ignore 'echo' volumes (eg. cygwin)\n" ) ;
		fprintf (stderr, " -B : output informations in HTML format (*2)\n" ) ;
		fprintf (stderr, " -C : output informations in CSV format (*2)\n" ) ;
		fprintf (stderr, " -X : extra host informations\n" ) ;
		fprintf (stderr, " -S : show total sizes and capacity average\n" ) ;
		fprintf (stderr, " -H : show header\n" ) ;
		fprintf (stderr, " -o : sort usage help\n" ) ;
		fprintf (stderr, " -v : verbose mode\n" ) ;
		fprintf (stderr, " -V : show version\n" ) ;
		fprintf (stderr, " -L : legacy df layout\n" ) ;
		fprintf (stderr, " -t : use 'static' (eg. fstab) filesystems list\n" ) ;
		fprintf (stderr, " -n <pathname> [ -n ... ] : process just these\n" ) ;
		fprintf (stderr, " -d 'delimiter' : CSV 'alternate field separator'\n" ) ;
	}
	fprintf (stderr, " (*1) '-A' and '-m' are mutually exclusive\n") ;
	fprintf (stderr, " (*2) '-B' , '-F' and '-C' are mutually exclusive\n") ;
	return 3 ;
}

/*	__	__	__	__	__	__	__	__	__
*/

void htmlhead () {
	printf ("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n") ;
	printf ("<html>\n") ;
	printf (" <head>\n") ;
	printf ("  <meta name=\"author\" content=\"Alexandre Botao, botao@unix.sh, botao@linux.sh, alexandre@botao.org\">\n") ;
	printf ("  <meta name=\"description\" content=\"%s\">\n", SWNAME) ;
	printf ("  <meta name=\"keywords\" content=\"%s,disk,free,usage,capacity\">\n", SWNAME) ;
	printf ("  <title> %s %s </title>\n", SWNAME, versno) ;
	printf ("  <style type=\"text/css\">\n") ;
	printf ("  p {color:cyan;font-family:Courier;}\n") ;
	printf ("  thead {color:blue;font-family:Courier;font-style:normal;font-weight:bold;}\n") ;
	printf ("  tbody {color:black;font-family:Courier;}\n") ;
	printf ("  tfoot {color:black;font-family:Courier;font-weight:bold;}\n") ;
	printf ("  td {padding:3px 5px;}\n") ;
	printf ("  caption {font-family:Arial;color:darkblue}\n") ;
	printf ("  </style>\n") ;
}

/*	__	__	__	__	__	__	__	__	__
*/

void htmlbody () {
	int bordersiz = 0 ;

	if ( borderflag )
		bordersiz = 4 ;
	printf (" </head>\n") ;
	printf (" <body>\n") ;
	printf ("   <p> %s </p>\n", banner) ;
	printf ("   <table border=s%d>\n", bordersiz) ;
	if ( identflag )
		printf ("    <caption> %s </caption>\n", hident) ;
}

/*	__	__	__	__	__	__	__	__	__
*/

void htmltail () {
	printf ("   </table>\n") ;
	printf (" </body>\n") ;
	printf ("</html>\n") ;
}

/*	__	__	__	__	__	__	__	__	__
*/

void showmesg (text) char * text ; {

	if ( htmlflag )
		return ;

	printf ("%s\n", text) ;
}

/*	__	__	__	__	__	__	__	__	__
*/

int ldf () {

	FILE * mfp ;
# ifdef SUNX
	struct mnttab mntbuf ;
# else
	struct mntent * mtp ;
# endif /* SUNX */
	char *	x_fsname; /* file system name */ 
	char *	x_dir;    /* file system path prefix */ 
	char *	x_type;
	char *	x_opts = NULL;
	char *	tp ;
	time_t	tloc ;
	int j ;

	getuname () ;

	strcpy (versno, SWVERS) ;

	if ( *forgid != '$' ) {
		strcat (versno, forgid) ;
	}

# ifdef		ANYBSD
	fsstabsiz = MAXFSS * sizeof ( FSSBUF ) ;
# endif		/* ANYBSD */

	if ( ansiflag ) {
		xdf_vertbar = 'x' ;
		xdf_horzbar = 'q' ; /* ?r? */
		xdf_plusign = 'n' ;
		xdf_upprtee = 'w' ;
		xdf_lowrtee = 'v' ;
		xdf_lefttee = 't' ;
		xdf_rightee = 'u' ;
		xdf_upprleft = 'l' ;
		xdf_uppright = 'k' ;
		xdf_lowrleft = 'm' ;
		xdf_lowright = 'j' ;
		++frameflag ;
	}

	if ( hostflag ) {
		hostname = noname ; /* or gethostname () ; */
	}

	if ( borderflag ) {
		++htmlflag ;
	}

	if ( frameflag ) {
		csvflag = htmlflag = 0 ;
	}

	if ( csvflag ) {
		frameflag = htmlflag = 0 ;
	}

	if ( htmlflag ) {
		csvflag = frameflag = 0 ;
	}

	strcpy (banner, SWNAME) ;

	if ( htmlflag ) {
		htmlhead () ;
	}

	if ( versflag ) {
		sprintf (banner, "%s %s %s (%s) %s", SWNAME, versno, SWDATE, SWCOPY, SWAUTH) ;
		showmesg (banner) ;
		exit (0) ;
	}

	if ( identflag ) {
		time ( &tloc ) ;
		lotime = ctime ( &tloc ) ;
		tp = lotime + strlen (lotime) ;
		if ( *--tp == '\n' )
			*tp = '\0' ;
		sprintf (hident, "%s %s v%s r%s %s", noname, osname, osvers, osrels, lotime) ;
		showmesg (hident) ;
	}

	if ( helpflag ) {
		return usage () ;
	}

	if ( ( bytesflag + sectorflag + kiloflag + megaflag + gigaflag + teraflag ) > 1 ) {
		fprintf (stderr, "\n>>> 'unit options' are mutually exclusive\n\n") ;
		return usage () ;
	}

	if ( htmlflag ) {
		htmlbody () ;
	}

	if ( humanflag ) {
		bigwid = 6 ;
	}

	if ( legflag ) {
		++volflag ;
		++sizflag ;
		++useflag ;
		++avaflag ;
		++capflag ;
		++mountflag ;
		++hdrflag ;
		if ( ! bytesflag ) {
			++kiloflag ;
		}
	}

	if ( capflag ) {
		freeflag = 0 ; /* capflag prevails if both are inadvertently set */
	} else {
		if ( freeflag ) {
			capflag = 0 ; /* there can be only one ! */
		}
	}

	if ( bytesflag || unit == 1 ) {
		unit = 1LL ;
		bigwid = 24 ;		/* ppp.ttt.ggg.mmm.kkk.uuu */
		unitname = "bytes" ;
	}

	if ( sectorflag ) {
		unit = 512LL ;
		bigwid = 20 ;
		unitname = "Sec" ;
	}

	if ( kiloflag ) {
		bigwid = 15 ;
		if ( siflag == 0 ) {
			unit = 1024LL ;
			unitname = "KiB" ;
		} else {
			unit = 1000LL ;
			unitname = "KB" ;
		}
	}

	if ( megaflag ) {
		bigwid = 11 ;
		if ( siflag == 0 ) {
			unit = 1048576LL ;
			unitname = "MiB" ;
		} else {
			unit = 1000000LL ;
			unitname = "MB" ;
		}
	}

	if ( gigaflag ) {
		bigwid = 11 ;
		if ( siflag == 0 ) {
			unit = 1073741824LL ;
			unitname = "GiB" ;
		} else {
			unit = 1000000000LL ;
			unitname = "GB" ;
		}
	}

	if ( teraflag ) {
		bigwid = 8 ;
		if ( siflag == 0 ) {
			unit = 1099511627776LL ;
			unitname = "TiB" ;
		} else {
			unit = 1000000000000LL ;
			unitname = "TB" ;
		}
	}

	if ( humanflag ) {
		bigwid = 6 ;
		unitname = "b" ;
	}

	dashes (XDF_HEAD) ;

	if ( hdrflag ) {
		showhdr () ;
	}

	if ( listflag ) {
		for ( j = 0 ; j < listflag ; ++j ) {
			xdf (NULL, dirlst[j]) ;
		}
	} else {
# ifdef	ANYBSD
		fsscount = FSSFILL ( fsstab , fsstabsiz , fssflags ) ;
		for ( fsno = 0 , fssp = fsstab ; fsno < fsscount ; ++fsno , ++fssp ) {
			x_type   = fssp->f_fstypename ;
			x_fsname = fssp->f_mntfromname ; 
			x_dir    = fssp->f_mntonname ;
# else	/* ! ANYBSD */
		if ( fstabflag ) {
			mfp = setmntent ( X_FILESYSLIST , "r" ) ;
		} else {
			mfp = setmntent ( X_MOUNTEDLIST , "r" ) ;
		}
		if ( mfp == NULL ) {
			perror ( X_MOUNTEDLIST ) ;
			return 2 ;
		}
#	ifdef	SUNX
		while ( getmntent ( mfp , &mntbuf ) == 0 ) {
			x_fsname = mntbuf.mnt_special ;
			x_dir    = mntbuf.mnt_mountp ;
			x_type   = mntbuf.mnt_fstype ;
			x_opts   = mntbuf.mnt_mntopts ;
#	else	/* ! SUNX */
		while ( ( mtp = getmntent ( mfp ) ) != NULL ) {
			x_fsname = mtp->mnt_fsname ;
			x_dir    = mtp->mnt_dir ;
			x_type   = mtp->mnt_type ;
			x_opts   = mtp->mnt_opts ;
#	endif	/* SUNX */
# endif	/* ANYBSD */
			if ( chkign ( x_type ) ) {
				continue ;
			}
			if ( 0 == strcmp ( x_type , "nfs" ) ) {
				if ( ! nfsflag ) {
					continue ;
				}
			}
			if ( sysflag ) {
				if ( ! chksys ( x_dir ) ) {
					continue ;
				}
			}
			if ( regflag ) {
				if ( chksys ( x_dir ) ) {
					continue ;
				}
			}
			if ( echoflag ) {
				if ( chkign ( x_fsname ) ) {
					continue ;
				}
			}
			if ( x_opts != NULL ) {
				if ( verbflag ) {
					printf ("opts(%s)\n", x_opts) ;
				}
			}
			xdf (x_fsname, x_dir) ;
		}
# ifndef	ANYBSD
		endmntent ( mfp ) ;
# endif		/* ANYBSD */
	}

	if ( sumflag ) {
		showsums () ;
	}

	dashes (XDF_TAIL) ;

	if ( htmlflag ) {
		htmltail () ;
	}

	return 0 ;
}

/*	__	__	__	__	__	__	__	__	__
*/

int sdf (name) char * name ; {
	if ( name == NULL )
		return -1 ;
	if ( listflag == MAXDIRLST )
		return -1 ;
	dirlst[listflag++] = strdup (name) ;
	return 0 ;
}

/*	__	__	__	__	__	__	__	__	__
*/

int main (argc, argv) int argc ; char * * argv ; {

	if (--argc) {
		while (*++argv) {
			if ( strcmp ( *argv , "-K" ) == 0 )
				++kiloflag ;
			else if ( strcmp ( *argv , "-M" ) == 0 )
				++megaflag ;
			else if ( strcmp ( *argv , "-G" ) == 0 )
				++gigaflag ;
			else if ( strcmp ( *argv , "-T" ) == 0 )
				++teraflag ;
			else if ( strcmp ( *argv , "-i" ) == 0 ) {
				++intlflag ; ++siflag ;
			} else if ( strcmp ( *argv , "-h" ) == 0 )
				++humanflag ;
			else if ( strcmp ( *argv , "-b" ) == 0 )
				++bytesflag ;
			else if ( strcmp ( *argv , "-F" ) == 0 )
				++frameflag ;
			else if ( strcmp ( *argv , "-X" ) == 0 )
				++identflag ;
			else if ( strcmp ( *argv , "-S" ) == 0 )
				++sumflag ;
			else if ( strcmp ( *argv , "-H" ) == 0 )
				++hdrflag ;
			else if ( strcmp ( *argv , "-v" ) == 0 )
				++verbflag ;
			else if ( strcmp ( *argv , "-V" ) == 0 )
				++versflag ;
			else if ( strcmp ( *argv , "-A" ) == 0 )
				++ansiflag ;
			else if ( strcmp ( *argv , "-C" ) == 0 )
				++csvflag ;
			else if ( strcmp ( *argv , "-l" ) == 0 )
				++volflag ;
			else if ( strcmp ( *argv , "-s" ) == 0 )
				++sizflag ;
			else if ( strcmp ( *argv , "-u" ) == 0 )
				++useflag ;
			else if ( strcmp ( *argv , "-a" ) == 0 )
				++avaflag ;
			else if ( strcmp ( *argv , "-c" ) == 0 )
				++capflag ;
			else if ( strcmp ( *argv , "-L" ) == 0 )
				++legflag ;
			else if ( strcmp ( *argv , "-m" ) == 0 )
				++borderflag ;
			else if ( strcmp ( *argv , "-B" ) == 0 )
				++htmlflag ;
			else if ( strcmp ( *argv , "-E" ) == 0 )
				++echoflag ;
			else if ( strcmp ( *argv , "-O" ) == 0 )
				++sysflag ;
			else if ( strcmp ( *argv , "-R" ) == 0 )
				++regflag ;
			else if ( strcmp ( *argv , "-N" ) == 0 )
				++nfsflag ;
			else if ( strcmp ( *argv , "-h" ) == 0 )
				++hostflag ;
			else if ( strcmp ( *argv , "-f" ) == 0 )
				++freeflag ;
			else if ( strcmp ( *argv , "-t" ) == 0 )
				++fstabflag ;
			else if ( strcmp ( *argv , "-n" ) == 0 )
				sdf (*++argv) ;
			else if ( strcmp ( *argv , "-5" ) == 0 )
				++sectorflag ;
			else if ( strcmp ( *argv , "-d" ) == 0 )
				csvsep = **++argv ;
			else if ( strcmp ( *argv , "-z" ) == 0 )
				++dotsflag ;
			else if ( strcmp ( *argv , "-o" ) == 0 )
				++sorthelp ;
			else if ( strcmp ( *argv , "-p" ) == 0 )
				++mountflag ;
			else if ( strcmp ( *argv , "-?" ) == 0 )
				++helpflag ;
			else
				fprintf (stderr, "%s: bad arg (%s)\n", SWNAME, *argv) ;
		}
	} else {
		++legflag ; ++humanflag ; ++sumflag ;
	}

	return ldf () ;
}

/*____________________________________________________________________________
*/

#ifdef XBSD

main () {
	for ( fsno = 0 , fssp = fsstab ; fsno < fsscount ; ++fsno , ++fssp ) {
		printf ( "%s %s %lld %lld %s \n" , 
			fssp->f_fstypename ,
			fssp->f_mntfromname , 
(long long) fssp->F_BLOCKSIZE , 
(long long) fssp->f_blocks , 
			fssp->f_mntonname
		) ;
	}
}

#endif

/*____________________________________________________________________________
 * vi:nu ts=4
 */

/*
 *	version.h
 */

# ifndef _VERSION_H_

# define _VERSION_H_

extern const char * xdf_program_string ;
extern const char * xdf_version_string ;
extern const char * xdf_release_string ;
extern const char * xdf_relogio_string ;
extern const char * xdf_summary_string ;
extern const char * xdf_taglist_string ;
extern const char * xdf_license_string ;
extern const char * xdf_creator_string ;
extern const char * xdf_contact_string ;
extern const char * xdf_builder_string ;
extern const char * xdf_compile_string ;

	/*  legacy  */

# define	SWNAME		xdf_program_string
# define	SWVERS		xdf_version_string
# define	SWDATE		xdf_release_string
# define	SWTIME		xdf_relogio_string
# define	SWDESC		xdf_summary_string
# define	SWTAGS		xdf_taglist_string
# define	SWCOPY		xdf_license_string
# define	SWAUTH		xdf_creator_string
# define	SWMAIL		xdf_contact_string
# define	SWBLDR		xdf_builder_string
# define	SWCOMP		xdf_compile_string

# define	SWFORG		" " /* deprecated */

# endif /* _VERSION_H_ */

/*
 * vi:nu ts=8
 */
